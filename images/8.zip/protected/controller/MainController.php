<?php
class MainController extends BaseController {
	function actionIndex(){
		
	}
}

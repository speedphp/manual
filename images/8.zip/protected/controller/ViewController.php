<?php
class ViewController extends BaseController {
	function actionIndex(){
		
	}
}

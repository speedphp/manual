-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2016-03-30 10:55:32
-- 服务器版本： 10.1.10-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- 表的结构 `guestbook`
--

CREATE TABLE `guestbook` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `contents` varchar(200) NOT NULL,
  `username` varchar(20) NOT NULL,
  `dig` int(11) DEFAULT '0',
  `createtime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `guestbook`
--

INSERT INTO `guestbook` (`id`, `title`, `contents`, `username`, `dig`, `createtime`) VALUES
(1, '我是标题', '我是内容', '我是jake', 4, 1459238353),
(3, '英文诗词', 'How to maintain customer interest in a company \r\nIt is very important for all companies to maintain current customers.As we know,customer is the god.The key point is to keep and improve quality of goo', 'jake', 0, 1459324781),
(4, '英文内容', 'attention to what customers need and interests.Keep pace with the fashion.And aslo have good services.the company tries to attract new customers by ads.', 'jake', 0, 1459324944),
(5, '雪落的日子', '北方的飘雪，不均匀的分布在深秋和整个冬季，还有初春，覆盖三个季节的雪，把秋日的凉与冬天的寒，冬日的冷与春天的暖交织在一起，共同鸣响的是季节的变奏。就在这秋天的末尾，这冬日的漫漫征程，还有春天苦苦的挣扎中，我们几乎不能没有雪的飘落，雪落雪融，冷暖交替的是入木三分的寒意逾深的袭来。雪融雪落，暖阳照在大地，出神入化的描绘着春天的样子。', '文学者', 0, 1459324994),
(6, '面朝阳光', '人间有味是清欢，我深爱这北方的飘雪的淡淡的味道，深秋，似水芳菲尽，云梦柳寒烟。那落雪的枝头，那被白雪点缀的分外鲜艳的花瓣，都在述说着花落成伤，雪落成景的季节故事。面朝阳光，晶莹剔透，五光十色繁星闪烁，雪如天使翩翩起舞；面朝天际，落雪如沐，却有飞瀑直下，雪如水幕一泻千里。仰望夜空，星光下的落雪如花，花与星光交织成天女散花的美景。', '面朝阳光', 0, 1459325007),
(7, '漫长的日子', '漫长的日子，唯有落雪的声音，需要静心聆听，原为无声来，我却听歌行。走在雪影下，静静的感受落雪的声音，簌簌的、细细的都在心里响起，有一种天籁之音从天而降。这就是落雪的意境，一种上帝赐予的雪世界的美妙音乐。', '漫长的日子', 0, 1459325021),
(8, '雪落的世界', '置身雪落的世界，我们似乎也宁静了许多，心的世界需要雪的融入，雪的世界需要我们更加细心的聆听。凡尘的燥扰，人世的喧嚣，都让这落雪的日子格外的亲切，我们的心向往着一种纯净的，无忧无虑的，静静的世界，而雪落的世界正是迎合了我们的祈盼。', '我们', 0, 1459325038);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `guestbook`
--
ALTER TABLE `guestbook`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `guestbook`
--
ALTER TABLE `guestbook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

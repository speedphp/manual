<?php
class MainController extends BaseController {
	function actionIndex(){
		$this->display("main_index.html");
	}

	function actionTop(){
		$this->display("main_top.html");
	}
	
	function actionBottom(){
		$this->display("main_bottom.html");
	}
}
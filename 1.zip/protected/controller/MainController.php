<?php
class MainController extends BaseController {
	function actionIndex(){
		echo "Hello World";
	}
}